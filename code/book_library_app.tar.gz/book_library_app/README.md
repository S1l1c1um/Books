# Book Library

A modern Flutter application for browsing and managing your personal book collection with a stunning Apple Liquid Glass design aesthetic.

## Features

### Core Functionality
- **Book Search**: Search millions of books using the Google Books API
- **My Personal Library**: Pre-loaded collection of 39 read books with ratings and favorites
- **Category Browsing**: Explore books by popular categories (Fiction, Science, Business, Fantasy, History)
- **Detailed Information**: View comprehensive book details including ratings, descriptions, page counts, and publication dates
- **Favorites Management**: Save and manage your favorite books locally
- **Personal Ratings**: View books with personal 10-point rating system
- **Filter Options**: Filter personal library by all books, favorites only, or rated books
- **Preview Links**: Direct access to Google Books preview pages
- **Persistent Storage**: Favorites and personal library are saved locally using SharedPreferences

### Design & UI
- **Liquid Glass Aesthetic**: Frosted glass containers with blur effects inspired by Apple's design language
- **Smooth Animations**: Staggered list animations and hero transitions
- **Gradient Accents**: Modern gradient buttons and category indicators
- **Responsive Layout**: Optimized for various screen sizes
- **Custom Widgets**: Reusable liquid glass components

## Technical Implementation

### Architecture
```
lib/
├── main.dart                          # Application entry point
├── models/
│   ├── book.dart                      # Book data model with JSON serialization
│   └── read_book.dart                 # Personal library book model with ratings
├── services/
│   ├── books_api_service.dart         # Google Books API integration
│   ├── favorites_service.dart         # Local storage management
│   └── my_library_service.dart        # Personal library management
├── screens/
│   ├── home_screen.dart               # Main browsing interface
│   ├── book_details_screen.dart       # Detailed book view
│   ├── favorites_screen.dart          # Favorites collection
│   └── my_library_screen.dart         # Personal reading library
└── widgets/
    ├── liquid_glass_container.dart    # Reusable glass morphism widget
    └── book_card.dart                 # Book list item component
```

### Key Technologies
- **Flutter SDK**: Cross-platform mobile development framework
- **Google Books API**: Book data and search functionality
- **SharedPreferences**: Local data persistence
- **Cached Network Image**: Efficient image loading and caching
- **Google Fonts**: Inter font family for modern typography

### Dependencies
```yaml
dependencies:
  google_fonts: ^6.1.0              # Typography
  http: ^1.1.0                      # API requests
  shared_preferences: ^2.2.2        # Local storage
  cached_network_image: ^3.3.1      # Image caching
  flutter_staggered_animations: ^1.1.1  # List animations
  shimmer: ^3.0.0                   # Loading effects
  flutter_rating_bar: ^4.0.1        # Star ratings
  url_launcher: ^6.2.5              # External links
```

## Getting Started

### Prerequisites
- Flutter SDK (3.0.0 or higher)
- Dart SDK (3.0.0 or higher)
- Android Studio / Xcode for mobile development
- A code editor (VS Code, Android Studio, etc.)

### Installation

1. Clone the repository
```bash
git clone https://github.com/yourusername/book_library.git
cd book_library
```

2. Install dependencies
```bash
flutter pub get
```

3. Run the application
```bash
flutter run
```

### Build for Production

**Android**
```bash
flutter build apk --release
```

**iOS**
```bash
flutter build ios --release
```

## API Integration

This application uses the Google Books API which provides:
- Book search functionality
- Detailed book metadata
- Cover images
- Ratings and reviews
- Preview links

No API key is required for basic usage, though rate limits apply.

## Screenshots

The app features:
- A gradient background with liquid glass containers
- Smooth category selection with visual feedback
- Detailed book cards with cover images and metadata
- Expandable book details with hero animations
- A dedicated favorites section

## Future Enhancements

Potential improvements:
- Reading progress tracking
- Custom book collections
- Barcode scanning for ISBN lookup
- Social features (sharing, recommendations)
- Dark mode support
- Offline reading lists
- Advanced filtering options

## Performance Optimizations

- Lazy loading of book lists
- Image caching for faster subsequent loads
- Efficient state management
- Minimal rebuilds using const constructors
- Optimized API calls

## Contributing

Contributions are welcome. Please follow these steps:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- Google Books API for providing book data
- Flutter team for the excellent framework
- Design inspiration from Apple's iOS design guidelines
- Community packages that made development faster

## Contact

For questions or feedback, please open an issue on GitHub.

---

**Built with Flutter**

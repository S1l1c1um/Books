# API Usage Examples

This document provides examples of how to use the Google Books API integration in this application.

## BooksApiService

### Searching for Books

```dart
final apiService = BooksApiService();

// Basic search
List<Book> books = await apiService.searchBooks('flutter development');

// Search with custom max results
List<Book> books = await apiService.searchBooks(
  'machine learning',
  maxResults: 40,
);
```

### Getting Popular Books

```dart
// Fetches bestseller books
List<Book> popularBooks = await apiService.getPopularBooks();
```

### Getting Books by Category

```dart
// Search for books in specific category
List<Book> scienceBooks = await apiService.getBooksByCategory('science');
List<Book> fictionBooks = await apiService.getBooksByCategory('fiction');
```

### Getting Book Details

```dart
// Fetch detailed information for a specific book
Book bookDetails = await apiService.getBookDetails('book_id_here');
```

## FavoritesService

### Adding to Favorites

```dart
final favoritesService = FavoritesService();
final book = Book(
  id: '123',
  title: 'Flutter Complete Guide',
  authors: ['John Doe'],
);

bool success = await favoritesService.addFavorite(book);
if (success) {
  print('Book added to favorites!');
}
```

### Removing from Favorites

```dart
bool success = await favoritesService.removeFavorite('book_id_123');
if (success) {
  print('Book removed from favorites!');
}
```

### Getting All Favorites

```dart
List<Book> favorites = await favoritesService.getFavorites();
print('You have ${favorites.length} favorite books');
```

### Checking if Book is Favorite

```dart
bool isFavorite = await favoritesService.isFavorite('book_id_123');
if (isFavorite) {
  print('This book is in your favorites!');
}
```

### Toggling Favorite Status

```dart
// Add if not favorite, remove if already favorite
bool result = await favoritesService.toggleFavorite(book);
```

## Book Model

### Creating from JSON

```dart
// From Google Books API response
final json = {
  'id': 'abc123',
  'volumeInfo': {
    'title': 'Sample Book',
    'authors': ['Author Name'],
    'description': 'Book description...',
    'imageLinks': {
      'thumbnail': 'https://example.com/image.jpg'
    },
    'averageRating': 4.5,
    'ratingsCount': 100,
    'publishedDate': '2024-01-01',
    'pageCount': 300,
    'categories': ['Technology', 'Programming'],
    'previewLink': 'https://books.google.com/...'
  }
};

Book book = Book.fromJson(json);
```

### Converting to JSON (for storage)

```dart
Map<String, dynamic> json = book.toJson();
```

### Creating from Storage

```dart
final storedJson = {
  'id': 'abc123',
  'title': 'Stored Book',
  'authors': ['Author'],
  'isFavorite': true,
  // ... other fields
};

Book book = Book.fromStorageJson(storedJson);
```

## Practical Examples

### Complete Search Flow

```dart
class BookSearchWidget extends StatefulWidget {
  @override
  _BookSearchWidgetState createState() => _BookSearchWidgetState();
}

class _BookSearchWidgetState extends State<BookSearchWidget> {
  final BooksApiService _apiService = BooksApiService();
  List<Book> _searchResults = [];
  bool _isLoading = false;

  Future<void> _performSearch(String query) async {
    setState(() {
      _isLoading = true;
    });

    try {
      final results = await _apiService.searchBooks(query);
      setState(() {
        _searchResults = results;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      // Handle error
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Search failed: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        TextField(
          onSubmitted: _performSearch,
          decoration: InputDecoration(
            hintText: 'Search books...',
          ),
        ),
        if (_isLoading)
          CircularProgressIndicator()
        else
          ListView.builder(
            itemCount: _searchResults.length,
            itemBuilder: (context, index) {
              return BookCard(book: _searchResults[index]);
            },
          ),
      ],
    );
  }
}
```

### Favorites Management

```dart
class FavoritesManager {
  final FavoritesService _service = FavoritesService();

  Future<void> addMultipleBooks(List<Book> books) async {
    for (var book in books) {
      await _service.addFavorite(book);
    }
  }

  Future<List<Book>> getFavoritesByCategory(String category) async {
    final favorites = await _service.getFavorites();
    return favorites.where((book) {
      return book.categories?.contains(category) ?? false;
    }).toList();
  }

  Future<void> clearAllFavorites() async {
    final favorites = await _service.getFavorites();
    for (var book in favorites) {
      await _service.removeFavorite(book.id);
    }
  }

  Future<Map<String, int>> getFavoriteStats() async {
    final favorites = await _service.getFavorites();
    
    return {
      'total': favorites.length,
      'withRatings': favorites.where((b) => b.averageRating != null).length,
      'averagePages': favorites
          .where((b) => b.pageCount != null)
          .map((b) => b.pageCount!)
          .reduce((a, b) => a + b) ~/ favorites.length,
    };
  }
}
```

### Error Handling

```dart
Future<List<Book>> safeSearch(String query) async {
  try {
    final apiService = BooksApiService();
    return await apiService.searchBooks(query);
  } on SocketException {
    throw Exception('No internet connection');
  } on HttpException {
    throw Exception('Server error');
  } on FormatException {
    throw Exception('Invalid response format');
  } catch (e) {
    throw Exception('Unknown error: $e');
  }
}
```

### Caching Implementation Example

```dart
class CachedBooksService {
  final BooksApiService _apiService = BooksApiService();
  final Map<String, List<Book>> _cache = {};
  
  Future<List<Book>> searchBooks(String query) async {
    // Check cache first
    if (_cache.containsKey(query)) {
      return _cache[query]!;
    }
    
    // Fetch from API
    final results = await _apiService.searchBooks(query);
    
    // Store in cache
    _cache[query] = results;
    
    return results;
  }
  
  void clearCache() {
    _cache.clear();
  }
}
```

## API Response Examples

### Successful Book Search Response

```json
{
  "kind": "books#volumes",
  "totalItems": 1000,
  "items": [
    {
      "id": "abc123",
      "volumeInfo": {
        "title": "Flutter Development",
        "authors": ["John Doe", "Jane Smith"],
        "description": "A comprehensive guide to Flutter...",
        "imageLinks": {
          "thumbnail": "https://books.google.com/image.jpg"
        },
        "averageRating": 4.5,
        "ratingsCount": 234,
        "publishedDate": "2024-01-15",
        "pageCount": 450,
        "categories": ["Technology", "Programming"],
        "previewLink": "https://books.google.com/books?id=abc123"
      }
    }
  ]
}
```

### Error Response

```json
{
  "error": {
    "code": 400,
    "message": "Invalid query parameter",
    "errors": [
      {
        "domain": "global",
        "reason": "invalid",
        "message": "Invalid query parameter"
      }
    ]
  }
}
```

## Best Practices

1. **Always handle errors** when calling API methods
2. **Use async/await** for better readability
3. **Show loading indicators** during API calls
4. **Cache results** when appropriate
5. **Limit API calls** to avoid rate limiting
6. **Validate user input** before searching
7. **Handle empty results** gracefully
8. **Provide user feedback** for long operations

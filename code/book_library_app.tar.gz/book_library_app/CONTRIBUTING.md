# Contributing to Book Library

Thank you for considering contributing to Book Library! This document provides guidelines for contributing to this project.

## Code of Conduct

### Our Standards
- Use welcoming and inclusive language
- Be respectful of differing viewpoints
- Accept constructive criticism gracefully
- Focus on what's best for the community
- Show empathy towards other contributors

## How to Contribute

### Reporting Bugs

Before creating bug reports, please check existing issues. When creating a bug report, include:

- **Clear title and description**
- **Steps to reproduce** the issue
- **Expected behavior** vs actual behavior
- **Screenshots** if applicable
- **Environment details** (OS, Flutter version, device)

Example:
```
Title: App crashes when searching for books with special characters

Steps to reproduce:
1. Open the app
2. Go to search
3. Type "test@#$"
4. App crashes

Expected: Should search or show error message
Actual: App crashes

Environment: Android 13, Flutter 3.16.0, Pixel 6
```

### Suggesting Enhancements

Enhancement suggestions are tracked as GitHub issues. Include:

- **Clear title** describing the enhancement
- **Detailed description** of the proposed functionality
- **Use cases** explaining why this would be useful
- **Possible implementation** if you have ideas

### Pull Requests

1. **Fork the repository** and create your branch from `main`
   ```bash
   git checkout -b feature/amazing-feature
   ```

2. **Make your changes**
   - Follow the existing code style
   - Add tests if applicable
   - Update documentation as needed

3. **Test your changes**
   ```bash
   flutter test
   flutter analyze
   ```

4. **Commit your changes**
   - Use clear, descriptive commit messages
   - Reference issues in commits (e.g., "Fixes #123")
   ```bash
   git commit -m "Add amazing feature that does X"
   ```

5. **Push to your fork**
   ```bash
   git push origin feature/amazing-feature
   ```

6. **Open a Pull Request**
   - Provide a clear description of the changes
   - Reference related issues
   - Include screenshots for UI changes

## Development Setup

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/book_library.git
   cd book_library
   ```

2. **Install dependencies**
   ```bash
   flutter pub get
   ```

3. **Run the app**
   ```bash
   flutter run
   ```

4. **Run tests**
   ```bash
   flutter test
   ```

## Coding Standards

### Dart/Flutter Style
- Follow the [Dart Style Guide](https://dart.dev/guides/language/effective-dart/style)
- Use `flutter analyze` to check for issues
- Format code with `dart format`

### Code Organization
```dart
// 1. Imports
import 'package:flutter/material.dart';
import 'package:package_name/package.dart';

import '../models/model.dart';
import '../widgets/widget.dart';

// 2. Class definition
class MyWidget extends StatelessWidget {
  // 3. Constants
  static const double padding = 16.0;
  
  // 4. Fields
  final String title;
  
  // 5. Constructor
  const MyWidget({super.key, required this.title});
  
  // 6. Build method
  @override
  Widget build(BuildContext context) {
    return Container();
  }
  
  // 7. Private methods
  void _privateMethod() {}
}
```

### Widget Guidelines
- Use `const` constructors whenever possible
- Extract complex widgets into separate files
- Keep build methods concise
- Use descriptive widget names

### State Management
- Use `setState` for simple local state
- Consider Provider/Riverpod for complex state
- Keep state as local as possible

### Comments
```dart
/// Documentation comments for public APIs
/// Use triple slashes for doc comments

// Regular comments for implementation details
// Use double slashes for inline comments

// TODO: Description of what needs to be done
// FIXME: Description of what needs to be fixed
```

### Testing
```dart
void main() {
  group('Book Model', () {
    test('should parse JSON correctly', () {
      // Arrange
      final json = {'title': 'Test Book'};
      
      // Act
      final book = Book.fromJson(json);
      
      // Assert
      expect(book.title, 'Test Book');
    });
  });
}
```

## Commit Message Guidelines

### Format
```
<type>(<scope>): <subject>

<body>

<footer>
```

### Types
- **feat**: New feature
- **fix**: Bug fix
- **docs**: Documentation changes
- **style**: Code style changes (formatting)
- **refactor**: Code refactoring
- **test**: Adding or updating tests
- **chore**: Maintenance tasks

### Examples
```
feat(search): add advanced search filters

Implemented filtering by author, year, and rating.
Added UI components for filter selection.

Closes #42
```

```
fix(favorites): resolve duplicate entries issue

Fixed bug where books could be added to favorites multiple times.
Added duplicate checking in FavoritesService.

Fixes #31
```

## Review Process

1. **Automated checks** must pass
   - Flutter analyze
   - Tests
   - Build verification

2. **Code review** by maintainers
   - Code quality
   - Test coverage
   - Documentation

3. **Approval and merge**
   - At least one approval required
   - Squash and merge preferred

## Recognition

Contributors will be recognized in:
- README.md contributors section
- Release notes
- Project documentation

## Questions?

Feel free to:
- Open an issue for discussion
- Join community discussions
- Contact maintainers

Thank you for contributing!

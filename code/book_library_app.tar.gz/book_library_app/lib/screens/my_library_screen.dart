import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import '../models/read_book.dart';
import '../services/my_library_service.dart';
import '../widgets/liquid_glass_container.dart';

class MyLibraryScreen extends StatefulWidget {
  const MyLibraryScreen({super.key});

  @override
  State<MyLibraryScreen> createState() => _MyLibraryScreenState();
}

class _MyLibraryScreenState extends State<MyLibraryScreen> {
  final MyLibraryService _libraryService = MyLibraryService();
  List<ReadBook> _books = [];
  bool _isLoading = true;
  String _filterMode = 'all'; // all, favorites, rated

  @override
  void initState() {
    super.initState();
    _loadLibrary();
  }

  Future<void> _loadLibrary() async {
    setState(() {
      _isLoading = true;
    });

    List<ReadBook> books;
    switch (_filterMode) {
      case 'favorites':
        books = await _libraryService.getFavoriteBooks();
        break;
      case 'rated':
        books = await _libraryService.getRatedBooks();
        break;
      default:
        books = await _libraryService.getMyLibrary();
    }

    if (mounted) {
      setState(() {
        _books = books;
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              const Color(0xFF6366F1).withOpacity(0.05),
              const Color(0xFF8B5CF6).withOpacity(0.05),
              const Color(0xFFEC4899).withOpacity(0.05),
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // Header
              Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        LiquidGlassContainer(
                          padding: EdgeInsets.zero,
                          child: IconButton(
                            icon: const Icon(Icons.arrow_back),
                            onPressed: () => Navigator.pop(context),
                          ),
                        ),
                        const SizedBox(width: 16),
                        const Expanded(
                          child: Text(
                            'Моя библиотека',
                            style: TextStyle(
                              fontSize: 28,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        FutureBuilder<Map<String, dynamic>>(
                          future: _libraryService.getStatistics(),
                          builder: (context, snapshot) {
                            if (!snapshot.hasData) return const SizedBox();
                            final stats = snapshot.data!;
                            return LiquidGlassContainer(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 12,
                                vertical: 8,
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  Text(
                                    '${stats['total']} книг',
                                    style: const TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  if (stats['averageRating'] > 0)
                                    Text(
                                      '⭐ ${stats['averageRating'].toStringAsFixed(1)}/10',
                                      style: TextStyle(
                                        fontSize: 12,
                                        color: Colors.grey.shade700,
                                      ),
                                    ),
                                ],
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    // Filter Buttons
                    Row(
                      children: [
                        _buildFilterChip('Все', 'all'),
                        const SizedBox(width: 8),
                        _buildFilterChip('Избранное', 'favorites'),
                        const SizedBox(width: 8),
                        _buildFilterChip('С оценками', 'rated'),
                      ],
                    ),
                  ],
                ),
              ),
              // Books List
              Expanded(
                child: _isLoading
                    ? const Center(child: CircularProgressIndicator())
                    : _books.isEmpty
                        ? Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.book_outlined,
                                  size: 80,
                                  color: Colors.grey.shade400,
                                ),
                                const SizedBox(height: 16),
                                Text(
                                  'Нет книг',
                                  style: TextStyle(
                                    fontSize: 18,
                                    color: Colors.grey.shade600,
                                  ),
                                ),
                              ],
                            ),
                          )
                        : AnimationLimiter(
                            child: ListView.builder(
                              padding: const EdgeInsets.symmetric(horizontal: 20),
                              itemCount: _books.length,
                              itemBuilder: (context, index) {
                                return AnimationConfiguration.staggeredList(
                                  position: index,
                                  duration: const Duration(milliseconds: 375),
                                  child: SlideAnimation(
                                    verticalOffset: 50.0,
                                    child: FadeInAnimation(
                                      child: _buildBookCard(_books[index], index),
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildFilterChip(String label, String mode) {
    final isSelected = _filterMode == mode;
    return GestureDetector(
      onTap: () {
        setState(() {
          _filterMode = mode;
        });
        _loadLibrary();
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          gradient: isSelected
              ? const LinearGradient(
                  colors: [Color(0xFF6366F1), Color(0xFF8B5CF6)],
                )
              : null,
          color: isSelected ? null : Colors.grey.shade200,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: isSelected ? Colors.white : Colors.grey.shade700,
            fontSize: 13,
            fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
          ),
        ),
      ),
    );
  }

  Widget _buildBookCard(ReadBook book, int index) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      child: LiquidGlassContainer(
        blur: 15,
        opacity: 0.15,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Book Icon/Number
            Container(
              width: 50,
              height: 70,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: book.isFavorite
                      ? [const Color(0xFFEC4899), const Color(0xFFF43F5E)]
                      : [Colors.grey.shade300, Colors.grey.shade400],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Center(
                child: book.isFavorite
                    ? const Icon(Icons.favorite, color: Colors.white, size: 24)
                    : Text(
                        '${index + 1}',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
              ),
            ),
            const SizedBox(width: 16),
            // Book Info
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    book.title,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      height: 1.3,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    book.author,
                    style: TextStyle(
                      fontSize: 13,
                      color: Colors.grey.shade700,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  if (book.rating != null) ...[
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 4,
                          ),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: _getRatingColors(book.rating!),
                            ),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(
                            '${book.rating}/10',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          _getRatingLabel(book.rating!),
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.grey.shade600,
                          ),
                        ),
                      ],
                    ),
                  ],
                ],
              ),
            ),
            // Favorite Star
            if (book.isFavorite)
              const Padding(
                padding: EdgeInsets.only(left: 8),
                child: Icon(
                  Icons.star,
                  color: Colors.amber,
                  size: 24,
                ),
              ),
          ],
        ),
      ),
    );
  }

  List<Color> _getRatingColors(int rating) {
    if (rating >= 9) {
      return [const Color(0xFF10B981), const Color(0xFF059669)]; // Green
    } else if (rating >= 7) {
      return [const Color(0xFF6366F1), const Color(0xFF8B5CF6)]; // Purple
    } else if (rating >= 5) {
      return [const Color(0xFFF59E0B), const Color(0xFFD97706)]; // Orange
    } else {
      return [const Color(0xFFEF4444), const Color(0xFFDC2626)]; // Red
    }
  }

  String _getRatingLabel(int rating) {
    if (rating == 10) return 'Шедевр!';
    if (rating >= 9) return 'Отлично';
    if (rating >= 7) return 'Хорошо';
    if (rating >= 5) return 'Нормально';
    return 'Так себе';
  }
}

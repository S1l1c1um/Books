import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/book.dart';

class FavoritesService {
  static const String _favoritesKey = 'favorite_books';

  Future<List<Book>> getFavorites() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final String? favoritesJson = prefs.getString(_favoritesKey);
      
      if (favoritesJson == null) {
        return [];
      }
      
      final List<dynamic> decoded = json.decode(favoritesJson);
      return decoded.map((item) => Book.fromStorageJson(item)).toList();
    } catch (e) {
      return [];
    }
  }

  Future<bool> addFavorite(Book book) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final favorites = await getFavorites();
      
      if (!favorites.any((b) => b.id == book.id)) {
        book.isFavorite = true;
        favorites.add(book);
        final String encoded = json.encode(
          favorites.map((b) => b.toJson()).toList()
        );
        return await prefs.setString(_favoritesKey, encoded);
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  Future<bool> removeFavorite(String bookId) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final favorites = await getFavorites();
      
      favorites.removeWhere((book) => book.id == bookId);
      final String encoded = json.encode(
        favorites.map((b) => b.toJson()).toList()
      );
      return await prefs.setString(_favoritesKey, encoded);
    } catch (e) {
      return false;
    }
  }

  Future<bool> isFavorite(String bookId) async {
    final favorites = await getFavorites();
    return favorites.any((book) => book.id == bookId);
  }

  Future<bool> toggleFavorite(Book book) async {
    if (await isFavorite(book.id)) {
      return await removeFavorite(book.id);
    } else {
      return await addFavorite(book);
    }
  }
}

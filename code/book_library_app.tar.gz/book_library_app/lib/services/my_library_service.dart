import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/read_book.dart';

class MyLibraryService {
  static const String _libraryKey = 'my_library_books';

  // Ваша личная библиотека
  static final List<ReadBook> _initialLibrary = [
    ReadBook(title: 'Книжный вор', author: 'Маркус Зузак', isFavorite: true),
    ReadBook(title: '1984', author: 'Джордж Оруэлл'),
    ReadBook(title: 'Голубятня на желтой поляне', author: 'Владислав Крапивин'),
    ReadBook(title: 'Пдг', author: 'Автор неизвестен'),
    ReadBook(title: 'На дне', author: 'Максим Горький', isFavorite: true),
    ReadBook(title: 'Детство', author: 'Максим Горький', isFavorite: true),
    ReadBook(title: 'Выстрел', author: 'А.С. Пушкин'),
    ReadBook(title: 'Над пропастью во ржи', author: 'Дж. Д. Сэлинджер', rating: 10, isFavorite: true),
    ReadBook(title: 'Вино из одуванчиков', author: 'Рэй Брэдбери', rating: 10, isFavorite: true),
    ReadBook(title: 'Убить пересмешника', author: 'Харпер Ли'),
    ReadBook(title: 'В списках не значился', author: 'Борис Васильев'),
    ReadBook(title: 'Белый клык', author: 'Джек Лондон'),
    ReadBook(title: 'Любовь к жизни', author: 'Джек Лондон', isFavorite: true),
    ReadBook(title: 'Сын полка', author: 'Валентин Катаев'),
    ReadBook(title: 'Четвёртая высота', author: 'Елена Ильина'),
    ReadBook(title: 'Голос', author: 'Автор неизвестен'),
    ReadBook(title: 'Мальчик на вершине горы', author: 'Джон Бойн', isFavorite: true),
    ReadBook(title: 'Мальчик в полосатой пижаме', author: 'Джон Бойн'),
    ReadBook(title: 'Портрет', author: 'Н.В. Гоголь'),
    ReadBook(title: 'Тенистый лес', author: 'Автор неизвестен'),
    ReadBook(title: 'Семнадцать мгновений весны', author: 'Юлиан Семёнов'),
    ReadBook(title: 'Герой нашего времени', author: 'М.Ю. Лермонтов'),
    ReadBook(title: 'Евгений Онегин', author: 'А.С. Пушкин'),
    ReadBook(title: 'Падение дома Ашеров', author: 'Эдгар Аллан По', isFavorite: true),
    ReadBook(title: 'Триумфальная арка', author: 'Эрих Мария Ремарк'),
    ReadBook(title: 'Приключения Тома Сойера', author: 'Марк Твен'),
    ReadBook(title: 'Последний день приговорённого к смерти', author: 'Виктор Гюго', isFavorite: true),
    ReadBook(title: 'Красный цветок', author: 'Всеволод Гаршин'),
    ReadBook(title: 'Палата номер 6', author: 'А.П. Чехов'),
    ReadBook(title: 'Береника', author: 'Эдгар Аллан По', rating: 10, isFavorite: true),
    ReadBook(title: 'Убийство на улице Морг', author: 'Эдгар Аллан По', rating: 10, isFavorite: true),
    ReadBook(title: 'Чёрный кот', author: 'Эдгар Аллан По', rating: 10, isFavorite: true),
    ReadBook(title: 'Три товарища', author: 'Эрих Мария Ремарк', rating: 10, isFavorite: true),
    ReadBook(title: 'В конце они оба умрут', author: 'Адам Сильвера', rating: 6),
    ReadBook(title: 'Весь невидимый нам свет', author: 'Энтони Дорр', rating: 8),
    ReadBook(title: 'Гранатовый браслет', author: 'А.И. Куприн', rating: 9),
    ReadBook(title: 'Грозовой перевал', author: 'Эмили Бронте', rating: 6),
    ReadBook(title: 'Преждевременные похороны', author: 'Эдгар Аллан По', rating: 10, isFavorite: true),
    ReadBook(title: 'Лигейя', author: 'Эдгар Аллан По', rating: 8),
  ];

  Future<List<ReadBook>> getMyLibrary() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final String? libraryJson = prefs.getString(_libraryKey);
      
      if (libraryJson == null) {
        // Инициализируем библиотеку первый раз
        await _saveLibrary(_initialLibrary);
        return _initialLibrary;
      }
      
      final List<dynamic> decoded = json.decode(libraryJson);
      return decoded.map((item) => ReadBook.fromJson(item)).toList();
    } catch (e) {
      return _initialLibrary;
    }
  }

  Future<bool> _saveLibrary(List<ReadBook> library) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final String encoded = json.encode(
        library.map((b) => b.toJson()).toList(),
      );
      return await prefs.setString(_libraryKey, encoded);
    } catch (e) {
      return false;
    }
  }

  Future<bool> addBook(ReadBook book) async {
    final library = await getMyLibrary();
    library.add(book);
    return await _saveLibrary(library);
  }

  Future<bool> updateBook(int index, ReadBook updatedBook) async {
    final library = await getMyLibrary();
    if (index >= 0 && index < library.length) {
      library[index] = updatedBook;
      return await _saveLibrary(library);
    }
    return false;
  }

  Future<bool> removeBook(int index) async {
    final library = await getMyLibrary();
    if (index >= 0 && index < library.length) {
      library.removeAt(index);
      return await _saveLibrary(library);
    }
    return false;
  }

  Future<List<ReadBook>> getFavoriteBooks() async {
    final library = await getMyLibrary();
    return library.where((book) => book.isFavorite).toList();
  }

  Future<List<ReadBook>> getRatedBooks() async {
    final library = await getMyLibrary();
    return library.where((book) => book.rating != null).toList();
  }

  Future<Map<String, dynamic>> getStatistics() async {
    final library = await getMyLibrary();
    final favorites = library.where((b) => b.isFavorite).length;
    final rated = library.where((b) => b.rating != null).toList();
    final averageRating = rated.isEmpty 
        ? 0.0 
        : rated.map((b) => b.rating!).reduce((a, b) => a + b) / rated.length;

    return {
      'total': library.length,
      'favorites': favorites,
      'rated': rated.length,
      'averageRating': averageRating,
    };
  }

  Future<bool> resetToDefault() async {
    return await _saveLibrary(_initialLibrary);
  }
}

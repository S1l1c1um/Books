import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/book.dart';

class BooksApiService {
  static const String _baseUrl = 'https://www.googleapis.com/books/v1';
  
  Future<List<Book>> searchBooks(String query, {int maxResults = 20}) async {
    try {
      final encodedQuery = Uri.encodeComponent(query);
      final url = Uri.parse(
        '$_baseUrl/volumes?q=$encodedQuery&maxResults=$maxResults&orderBy=relevance'
      );
      
      final response = await http.get(url);
      
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final items = data['items'] as List<dynamic>? ?? [];
        
        return items.map((item) => Book.fromJson(item)).toList();
      } else {
        throw Exception('Failed to load books');
      }
    } catch (e) {
      throw Exception('Error searching books: $e');
    }
  }

  Future<List<Book>> getPopularBooks() async {
    return searchBooks('bestseller', maxResults: 30);
  }

  Future<List<Book>> getBooksByCategory(String category) async {
    return searchBooks('subject:$category', maxResults: 20);
  }

  Future<Book> getBookDetails(String bookId) async {
    try {
      final url = Uri.parse('$_baseUrl/volumes/$bookId');
      final response = await http.get(url);
      
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return Book.fromJson(data);
      } else {
        throw Exception('Failed to load book details');
      }
    } catch (e) {
      throw Exception('Error getting book details: $e');
    }
  }
}

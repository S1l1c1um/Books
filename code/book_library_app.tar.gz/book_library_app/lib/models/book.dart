class Book {
  final String id;
  final String title;
  final List<String> authors;
  final String? description;
  final String? thumbnailUrl;
  final double? averageRating;
  final int? ratingsCount;
  final String? publishedDate;
  final int? pageCount;
  final List<String>? categories;
  final String? previewLink;
  bool isFavorite;

  Book({
    required this.id,
    required this.title,
    required this.authors,
    this.description,
    this.thumbnailUrl,
    this.averageRating,
    this.ratingsCount,
    this.publishedDate,
    this.pageCount,
    this.categories,
    this.previewLink,
    this.isFavorite = false,
  });

  factory Book.fromJson(Map<String, dynamic> json) {
    final volumeInfo = json['volumeInfo'] ?? {};
    final imageLinks = volumeInfo['imageLinks'] ?? {};
    
    return Book(
      id: json['id'] ?? '',
      title: volumeInfo['title'] ?? 'Unknown Title',
      authors: List<String>.from(volumeInfo['authors'] ?? ['Unknown Author']),
      description: volumeInfo['description'],
      thumbnailUrl: imageLinks['thumbnail']?.replaceAll('http:', 'https:'),
      averageRating: volumeInfo['averageRating']?.toDouble(),
      ratingsCount: volumeInfo['ratingsCount'],
      publishedDate: volumeInfo['publishedDate'],
      pageCount: volumeInfo['pageCount'],
      categories: volumeInfo['categories'] != null
          ? List<String>.from(volumeInfo['categories'])
          : null,
      previewLink: volumeInfo['previewLink'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'authors': authors,
      'description': description,
      'thumbnailUrl': thumbnailUrl,
      'averageRating': averageRating,
      'ratingsCount': ratingsCount,
      'publishedDate': publishedDate,
      'pageCount': pageCount,
      'categories': categories,
      'previewLink': previewLink,
      'isFavorite': isFavorite,
    };
  }

  factory Book.fromStorageJson(Map<String, dynamic> json) {
    return Book(
      id: json['id'] ?? '',
      title: json['title'] ?? 'Unknown Title',
      authors: List<String>.from(json['authors'] ?? ['Unknown Author']),
      description: json['description'],
      thumbnailUrl: json['thumbnailUrl'],
      averageRating: json['averageRating']?.toDouble(),
      ratingsCount: json['ratingsCount'],
      publishedDate: json['publishedDate'],
      pageCount: json['pageCount'],
      categories: json['categories'] != null 
          ? List<String>.from(json['categories'])
          : null,
      previewLink: json['previewLink'],
      isFavorite: json['isFavorite'] ?? false,
    );
  }
}

class ReadBook {
  final String title;
  final String author;
  final bool isFavorite;
  final int? rating; // из 10
  final bool isRead;
  final DateTime? dateRead;
  final String? notes;

  ReadBook({
    required this.title,
    this.author = 'Unknown',
    this.isFavorite = false,
    this.rating,
    this.isRead = true,
    this.dateRead,
    this.notes,
  });

  Map<String, dynamic> toJson() {
    return {
      'title': title,
      'author': author,
      'isFavorite': isFavorite,
      'rating': rating,
      'isRead': isRead,
      'dateRead': dateRead?.toIso8601String(),
      'notes': notes,
    };
  }

  factory ReadBook.fromJson(Map<String, dynamic> json) {
    return ReadBook(
      title: json['title'] ?? '',
      author: json['author'] ?? 'Unknown',
      isFavorite: json['isFavorite'] ?? false,
      rating: json['rating'],
      isRead: json['isRead'] ?? true,
      dateRead: json['dateRead'] != null 
          ? DateTime.parse(json['dateRead'])
          : null,
      notes: json['notes'],
    );
  }

  ReadBook copyWith({
    String? title,
    String? author,
    bool? isFavorite,
    int? rating,
    bool? isRead,
    DateTime? dateRead,
    String? notes,
  }) {
    return ReadBook(
      title: title ?? this.title,
      author: author ?? this.author,
      isFavorite: isFavorite ?? this.isFavorite,
      rating: rating ?? this.rating,
      isRead: isRead ?? this.isRead,
      dateRead: dateRead ?? this.dateRead,
      notes: notes ?? this.notes,
    );
  }
}

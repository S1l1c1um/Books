# Development Guide

## Project Overview

This Flutter application demonstrates modern mobile development practices with a focus on clean architecture, beautiful UI design, and efficient performance.

## Code Quality

### Linting
The project uses `flutter_lints` package with additional custom rules in `analysis_options.yaml`:
- Enforces const constructors where possible
- Requires trailing commas for better formatting
- Discourages print statements in production code
- Ensures proper return type declarations

### Best Practices Implemented
- Separation of concerns (models, services, widgets, screens)
- Reusable widget components
- Efficient state management
- Proper error handling
- Async/await patterns for API calls
- Hero animations for smooth transitions
- Image caching for performance
- Local storage for persistence

## Architecture Patterns

### Service Layer
- `BooksApiService`: Handles all Google Books API interactions
- `FavoritesService`: Manages local storage of favorite books

### Widget Structure
- Stateless widgets for static content
- Stateful widgets only when state management is needed
- Custom reusable components (LiquidGlassContainer, BookCard)
- Const constructors for better performance

### State Management
- Local state using setState for simple cases
- Services pattern for data fetching and storage
- Future builders where appropriate

## Design System

### Colors
- Primary: `#6366F1` (Indigo)
- Secondary: `#8B5CF6` (Purple)
- Accent: `#EC4899` (Pink)
- Gradients used throughout for modern look

### Typography
- Font: Inter (via Google Fonts)
- Sizes: 32px (headers), 16-18px (body), 12-14px (captions)

### Spacing
- Base unit: 8px
- Standard padding: 16px or 20px
- Card margins: 16px bottom

### Border Radius
- Small: 12px
- Medium: 16px
- Large: 20px

## Testing Recommendations

### Unit Tests
```dart
test/
├── models/
│   └── book_test.dart
├── services/
│   ├── books_api_service_test.dart
│   └── favorites_service_test.dart
└── widgets/
    └── book_card_test.dart
```

### Widget Tests
Test key UI components:
- BookCard rendering
- LiquidGlassContainer appearance
- Screen navigation flows

### Integration Tests
- Complete user flows
- API integration
- Favorites persistence

## Performance Optimization Tips

1. **Images**
   - Use CachedNetworkImage for all network images
   - Implement proper placeholder and error widgets
   - Consider image compression for custom assets

2. **Lists**
   - Use ListView.builder for dynamic lists
   - Implement pagination for large datasets
   - Cache list items where possible

3. **State**
   - Minimize widget rebuilds
   - Use const constructors
   - Implement shouldRebuild checks

4. **Network**
   - Cache API responses
   - Implement request debouncing for search
   - Handle offline scenarios gracefully

## Extending the Application

### Adding New Features

**Reading Lists**
```dart
class ReadingList {
  final String id;
  final String name;
  final List<Book> books;
  // Implementation
}
```

**Dark Mode**
```dart
ThemeData darkTheme = ThemeData(
  brightness: Brightness.dark,
  // Dark theme configuration
);
```

**Advanced Search**
```dart
Future<List<Book>> advancedSearch({
  String? author,
  String? publisher,
  int? year,
}) async {
  // Implementation
}
```

### UI Customization

Modify colors in `main.dart`:
```dart
colorScheme: ColorScheme.fromSeed(
  seedColor: const Color(0xFFYourColor),
),
```

Adjust glass effect in `liquid_glass_container.dart`:
```dart
LiquidGlassContainer(
  blur: 20.0,  // Increase for more blur
  opacity: 0.2, // Increase for more opacity
)
```

## Deployment

### Android Release
1. Update version in `pubspec.yaml`
2. Create keystore for signing
3. Configure `android/app/build.gradle`
4. Build: `flutter build apk --release`

### iOS Release
1. Update version and build number
2. Configure signing in Xcode
3. Build: `flutter build ios --release`
4. Upload via App Store Connect

## Common Issues & Solutions

**API Rate Limiting**
- Implement request caching
- Add debouncing to search
- Consider API key for higher limits

**Image Loading Failures**
- Check network connectivity
- Verify HTTPS URLs
- Implement proper error handling

**Storage Issues**
- Monitor storage size
- Implement data cleanup
- Consider database for large datasets

## Contributing Guidelines

1. Follow the existing code style
2. Write meaningful commit messages
3. Add tests for new features
4. Update documentation
5. Use feature branches
6. Request code review before merging

## Resources

- [Flutter Documentation](https://flutter.dev/docs)
- [Google Books API](https://developers.google.com/books)
- [Material Design Guidelines](https://material.io/design)
- [Flutter Best Practices](https://flutter.dev/docs/perf/best-practices)
